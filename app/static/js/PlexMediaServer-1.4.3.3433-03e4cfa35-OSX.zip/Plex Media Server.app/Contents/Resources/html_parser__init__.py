
html_parser_utf8 = HTMLParser(encoding='utf-8')

