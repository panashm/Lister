#
#  Plex Media Framework
#  Copyright (C) 2008-2009 Plex, Inc. (James Clarke, Elan Feingold). All Rights Reserved.
#

CACHE_1MINUTE     = 60
CACHE_1HOUR       = 3600
CACHE_1DAY        = 86400
CACHE_1WEEK       = 604800
CACHE_1MONTH      = 2592000