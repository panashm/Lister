import PhotoFiles

# Scans through files, and add to the media list.
def Scan(path, files, mediaList, subdirs, language=None, root=None, **kwargs):
  PhotoFiles.Scan(path, files, mediaList, subdirs, language, root);
