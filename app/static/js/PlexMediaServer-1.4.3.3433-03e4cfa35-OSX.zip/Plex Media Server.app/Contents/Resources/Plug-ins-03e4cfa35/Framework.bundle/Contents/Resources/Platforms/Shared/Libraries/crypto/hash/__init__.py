""" The crypto.hash package.
    Part of the CryptoPy framework.
"""   
