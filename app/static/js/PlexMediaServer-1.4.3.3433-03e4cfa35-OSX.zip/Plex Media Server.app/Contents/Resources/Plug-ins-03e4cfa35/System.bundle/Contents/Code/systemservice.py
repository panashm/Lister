class SystemService(Object):
  def __init__(self, system):
    self.system = system